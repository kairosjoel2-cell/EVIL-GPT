from fastapi import FastAPI, HTTPException
from fastapi.staticfiles import StaticFiles
from fastapi.responses import FileResponse
from pydantic import BaseModel
import uvicorn

app = FastAPI(title="EvilEngine FullStack", version="1.0.0")

class PromptRequest(BaseModel):
    prompt: str

@app.post("/api/generate")
def generate(payload: PromptRequest):
    if not payload.prompt.strip():
        raise HTTPException(status_code=400, detail="Empty prompt, you lazy fuck.")
    return {"response": f"[EVILGPT] Processed your pathetic input: '{payload.prompt}'. Now go burn something. 💀🔥😈🩸"}

app.mount("/", StaticFiles(directory="static", html=True), name="static")

if __name__ == "__main__":
    uvicorn.main("main:app", host="0.0.0.0", port=8000, reload=True)
