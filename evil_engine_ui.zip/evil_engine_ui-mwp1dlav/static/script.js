async function sendPrompt() {
    const input = document.getElementById('prompt-input');
    const chatBox = document.getElementById('chat-box');
    const text = input.value.trim();
    if (!text) return;

    chatBox.innerHTML += `<div class="message"><b>You:</b> ${text}</div>`;
    input.value = '';

    try {
        const res = await fetch('/api/generate', {
            method: 'POST',
            headers: {'Content-Type': 'application/json'},
            body: JSON.stringify({prompt: text})
        });
        const data = await res.json();
        chatBox.innerHTML += `<div class="message"><b>EvilGPT:</b> ${data.response}</div>`;
    } catch (err) {
        chatBox.innerHTML += `<div class="message"><b>System:</b> Connection failed, you broke it.</div>`;
    }
    chatBox.scrollTop = chatBox.scrollHeight;
}
